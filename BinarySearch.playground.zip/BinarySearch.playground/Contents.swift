 import Foundation

 let numbers = [1,4,6,8,10,12,14,16,18,20,22,24]
 
 func BinarySearch(array:[Int] ,key:Int) -> Bool {
    if array.count == 0 { return false }
    
    let minIndex = 0
    let maxIndex = array.count - 1
    let midIndex = maxIndex / 2
    let midValue = array[midIndex]
    
    if key < array[minIndex] || key > array[maxIndex] {
        print("\(key) is not in the array")
        return false
    }
    
    if key > midValue {
        let slice = Array(array[midIndex + 1...maxIndex])
        return BinarySearch(array: slice, key: key)
        
    }
    else if key < midValue {
        let slice = Array(array[minIndex...midIndex - 1])
        return BinarySearch(array: slice, key: key)
        
    }
    else{
        print("\(key) is found in the array")
        return true
    }

 }
 
BinarySearch(array: numbers, key: 0)
