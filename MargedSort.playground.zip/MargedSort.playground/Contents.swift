import Foundation

func mergeSort(array: [Int]) -> [Int] {
    guard array.count > 1 else {
        return array
    }
    let leftArray = Array(array[0..<array.count/2])
    let rightArray = Array(array[array.count/2..<array.count])
    
    return merge(left: mergeSort(array: leftArray), right: mergeSort(array: rightArray))
    
}

func merge(left: [Int] , right: [Int]) -> [Int] {
    
    var mergedArray: [Int] = []
    var left = left
    var right = right
    
    print("left \(left)")
    print("right \(right)")
    
    while left.count > 0 && right.count > 0 {
        if left.first! < right.first! {
            mergedArray.append(left.removeFirst())
        }
        else{
            mergedArray.append(right.removeFirst())
        }
    }
    return mergedArray + left + right
}

var random_unsorted = [2,3,10,5,8,6,7,1]
//for _ in 0...10 {
//    random_unsorted.append(Int(arc4random_uniform(UInt32(100))))
//}
print(random_unsorted)
print()
let sorted_random = mergeSort(array: random_unsorted)

print(sorted_random)

